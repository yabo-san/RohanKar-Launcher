RohanKar Launcher e2e fixture
